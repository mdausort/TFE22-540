# -*- coding: utf-8 -*-
"""
Created on Mon Dec 19 15:12:26 2022

@author: manou
"""

